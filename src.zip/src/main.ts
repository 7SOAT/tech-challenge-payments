import bootstrap from "bootstrap";

require('dotenv').config();

bootstrap();