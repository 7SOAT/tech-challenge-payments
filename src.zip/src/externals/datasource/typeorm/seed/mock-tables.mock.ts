import { INestApplication } from "@nestjs/common";
import PaymentStatusRepository from "../repositories/payment-status.repository";
import PaymentStatusMock from "./seed-tables/payment-status.seed";

export default async function MockTables(app: INestApplication<any>) {
  await HandleDomainTablesData(app);
}

async function HandleDomainTablesData(app: INestApplication<any>) {
  await mockTableHandler(app, PaymentStatusRepository, PaymentStatusMock);
}

async function mockTableHandler(app: INestApplication<any>, gateway: any, mockList) {
  const gatewayInstance: typeof gateway = app.get<typeof gateway>(gateway);
  await gatewayInstance.findAll().then(orderStatusList => {
    const orderStatusString = JSON.stringify(orderStatusList.map(x => x.id))
    mockList.forEach(mock => {
      if (!orderStatusString.includes(mock.id.toString())) {
        { gatewayInstance.insert(mock) }
      }
    })
  })
}