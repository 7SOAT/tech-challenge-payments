import { HttpModule } from "@nestjs/axios";
import { DynamicModule } from "@nestjs/common";
import { TerminusModule } from "@nestjs/terminus";
import PaymentProviderGateway from "adapters/gateways/payment-provider.gateway";
import EnvironmentConfigService from "api/config/environment-config/environment-config.service";
import RepositoriesModule from "externals/datasource/typeorm/repositories/repositories.module";
import PaymentProvider from "externals/providers/mercado-pago/mercado-pago.provider";
import ProvidersModule from "externals/providers/providers.module";
import PaymentRoute from "./payment/payment.route";

export default class RoutesModule {
    static resgister(): DynamicModule {
        return {
            module: this,
            imports: [TerminusModule, HttpModule, RepositoriesModule.resgister(), ProvidersModule.register()],
            providers: [
                EnvironmentConfigService,
                PaymentProvider,
                PaymentProviderGateway
            ],
            controllers: [
                PaymentRoute
            ]
        }
    }
};