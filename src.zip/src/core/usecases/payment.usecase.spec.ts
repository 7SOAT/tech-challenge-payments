import PaymentEntity from '../entities/payment/payment.entity';
import PaymentStatusEnum from '../enums/payment-status.enum';
import { Test, TestingModule } from '@nestjs/testing';
import PaymentUseCase from './payment.usecase';
import OrderStatusEnum from '../enums/order-status.enum';
import ProductCategory from '../enums/product-category.enum';
import OrderProviderGateway from 'adapters/gateways/order-provider.gateway';
import PaymentProviderGateway from 'adapters/gateways/payment-provider.gateway';
import IPaymentGateway from 'package/interfaces/datasource/payment.gateway';

const mockPayment = new PaymentEntity(
    {id: PaymentStatusEnum.PENDING}, 
    41234234,
    "bce68ef9-def4-4e91-af11-0600893f7817",
    {
        id: "4d99df56-d7fa-411f-a468-3a01a24bd982",
        totalValue: 100,
        status: {id: OrderStatusEnum.PENDING},
        customerId: "4d99df56-d7fa-411f-a468-3a01a24bd982",
        orderNumber: 543534534,
        payment: this,
        products: [{
            category: ProductCategory.Beverage, 
            description: "a", 
            id: "4d99df56-d7fa-411f-a468-3a01a24bd982", 
            name: "fds", 
            price: 453
        }]
    }
);

const mockOrderProviderGateway = {
    findById: jest.fn().mockResolvedValue(mockPayment.order),
} as Partial<OrderProviderGateway> as OrderProviderGateway;

const mockPaymentGateway = {
    processPayment: jest.fn().mockResolvedValue({ success: true }),
    updatePaymentStatus: jest.fn().mockResolvedValue({ success: true }),
} as Partial<IPaymentGateway> as IPaymentGateway;

const mockPaymentProviderGateway = {
    createOrderPayment: jest.fn().mockResolvedValue(mockPayment),
} as Partial<PaymentProviderGateway> as PaymentProviderGateway;

describe('PaymentUseCase', () => {
    let paymentUseCase: PaymentUseCase;

    beforeEach(async () => {
        const module: TestingModule = await Test.createTestingModule({
            providers: [
                {
                    provide: PaymentUseCase,
                    useFactory: () => new PaymentUseCase(
                        mockOrderProviderGateway,
                        mockPaymentGateway,
                        mockPaymentProviderGateway
                    ),
                },
            ],
        }).compile();

        paymentUseCase = module.get<PaymentUseCase>(PaymentUseCase);
    });

    it('should create a payment successfully', async () => {
        const payment = await paymentUseCase.createPayment(mockPayment.order.id);

        expect(mockPaymentProviderGateway.createOrderPayment).toHaveBeenCalled();
        expect(payment).toEqual(mockPayment);
    });
});