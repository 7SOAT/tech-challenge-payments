enum PaymentStatusEnum {
  PENDING = 0,
  CREATED = 1,
  APPROVED = 2,
  REJECTED = 3
}

export default PaymentStatusEnum;