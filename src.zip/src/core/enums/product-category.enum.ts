enum ProductCategory {
  Burger = "burger",
  Side = "side",
  Beverage = "beverage",
  Dessert = "dessert",
}

export default ProductCategory;
