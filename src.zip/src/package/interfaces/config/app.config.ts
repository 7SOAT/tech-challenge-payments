export default interface AppConfig{
    getApiPort(): number;
}