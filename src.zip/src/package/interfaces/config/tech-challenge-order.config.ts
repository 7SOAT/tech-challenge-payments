export default interface OrderConfig{
    getTechChallengeOrderBaseUrl(): string;
}